export const postAndColumnReinforcement = [
  {
    individual_parts: "m",
    lesser_than_commercial_input: 476,
    greater_than_commercial_input: 512,
  },
  {
    manual_total_length: "m",
    lesser_than_commercial_input: 624,
    greater_than_commercial_input: 660,
  },
];
