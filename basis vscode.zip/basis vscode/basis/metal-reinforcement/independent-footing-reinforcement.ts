export const indpendentFootingReinforcement = [
  {
    axis: "X",
    length_per_cut: 1.2,
    number: 6,
    total_number: 180,
    cut_bars: 5,
  },
  {
    axis: "Y",
    length_per_cut: 1.2,
    number: 6,
    total_number: 180,
    cut_bars: 5,
  },
];
