export const squareRectangularBasis = [
  {
    thickness_of_plywood: "6mm(1/4in)",
    size_of_wood_frame: [
      {
        name: "2inx2in",
        value: 29.67,
      },
      {
        name: "2inx3in",
        value: 44.5,
      },
    ],
  },
  {
    thickness_of_plywood: "12mm(1/2in)",
    size_of_wood_frame: [
      {
        name: "2inx2in",
        value: 20.33,
      },
      {
        name: "2inx3in",
        value: 30.5,
      },
    ],
  },
];
