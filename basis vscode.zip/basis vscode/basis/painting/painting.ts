export const painting = [
  {
    primers: [
      {
        primer: [
          {
            kind_of_paint: "Interior Primer and sealer",
            thinner: "Paint Tinner",
            coverage_per_area_sq_m: "27.5",
          },
        ],
      },
    ],
  },
  {
    primers: [
      {
        primer: [
          {
            kind_of_paint: "Exterior wood primer",
            thinner: "Paint Tinner",
            coverage_per_area_sq_m: "35",
          },
        ],
      },
    ],
  },
  {
    primers: [
      {
        primer: [
          {
            kind_of_paint: "Prepakote Red Oxide Primer",
            thinner: "Paint Tinner",
            coverage_per_area_sq_m: "37.5",
          },
        ],
      },
    ],
  },
  {
    primers: [
      {
        primer: [
          {
            kind_of_paint: "Zinc Chromate primer",
            thinner: "Paint Tinner",
            coverage_per_area_sq_m: 35,
          },
        ],
      },
    ],
  },
  {
    primers: [
      {
        primer: [
          {
            kind_of_paint: "Red Oxide Primer",
            thinner: "Paint Tinner",
            coverage_per_area_sq_m: 35,
          },
        ],
      },
    ],
  },
  {
    primers: [
      {
        primer: [
          {
            kind_of_paint: "Epoxy primer",
            thinner: "Paint Tinner",
            coverage_per_area_sq_m: 35,
          },
        ],
      },
    ],
  },
];
