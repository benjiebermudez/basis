export const estimateForCHBMultiplier = 12.5;
