export const vinylAndRubberTIles = [
  {
    stock_size: "20 x 20",
    number_per_sq_m: 25,
    gallons_on_adhesive_per_sq_m: 0.42,
  },
  {
    stock_size: "22.5 x 22.5",
    number_per_sq_m: 19.75,
    gallons_on_adhesive_per_sq_m: 0.42,
  },
  {
    stock_size: "25 x 25",
    number_per_sq_m: 16,
    gallons_on_adhesive_per_sq_m: 0.42,
  },
  {
    stock_size: "30 x 30",
    number_per_sq_m: 11.11,
    gallons_on_adhesive_per_sq_m: 0.42,
  },
  {
    stock_size: "40 x 40",
    number_per_sq_m: 6.25,
    gallons_on_adhesive_per_sq_m: 0.42,
  },
  {
    stock_size: "60 x 60",
    number_per_sq_m: 6.25,
    gallons_on_adhesive_per_sq_m: 0.42,
  },
];
